import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addItem, setFilterCategory, setSortBy } from '../store/cartSlice';
import { Card, CardContent, Typography, Button, Grid, Container, FormControl, InputLabel, Select, MenuItem } from '@mui/material';

const groceryItems = [
  { name: 'Apple', price: 139, category: 'Fruits' },
  { name: 'Banana', price: 130, category: 'Fruits' },
  { name: 'Carrot', price: 150, category: 'Vegetables' },
  { name: 'Watermelon', price: 190, category: 'Fruits' },
  { name: 'Cabbage', price: 110, category: 'Vegetables' },
  { name: 'Jackfruit', price: 125, category: 'Fruits' },
  { name: 'Milk', price: 160, category: 'Dairy' },
  { name: 'Cheese', price: 200, category: 'Dairy' },
];

const GroceryList = () => {
  const dispatch = useDispatch();
  const { filterCategory, sortBy } = useSelector(state => state.cart);

  
  const filteredItems = groceryItems.filter(item =>
    filterCategory === 'all' ? true : item.category === filterCategory
  );

  
  const sortedItems = [...filteredItems].sort((a, b) => {
    if (sortBy === 'lowToHigh') return a.price - b.price;
    if (sortBy === 'highToLow') return b.price - a.price;
    return 0;
  });

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Grocery List
      </Typography>

    
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        <FormControl style={{ minWidth: 150 }}>
          <InputLabel>Filter by Category</InputLabel>
          <Select
            value={filterCategory}
            onChange={(e) => dispatch(setFilterCategory(e.target.value))}
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="Fruits">Fruits</MenuItem>
            <MenuItem value="Vegetables">Vegetables</MenuItem>
            <MenuItem value="Dairy">Dairy</MenuItem>
          </Select>
        </FormControl>

        <FormControl style={{ minWidth: 150 }}>
          <InputLabel>Sort by Price</InputLabel>
          <Select
            value={sortBy}
            onChange={(e) => dispatch(setSortBy(e.target.value))}
          >
            <MenuItem value="none">None</MenuItem>
            <MenuItem value="lowToHigh">Low to High</MenuItem>
            <MenuItem value="highToLow">High to Low</MenuItem>
          </Select>
        </FormControl>
      </div>

      
      <Grid container spacing={2}>
        {sortedItems.map((item) => (
          <Grid item xs={12} sm={6} md={4} key={item.name}>
            <Card sx={{ minWidth: 200, textAlign: 'center', p: 2 }}>
              <CardContent>
                <Typography variant="h6">{item.name}</Typography>
                <Typography variant="body1">${item.price}</Typography>
                <Typography variant="body2" color="textSecondary">Category: {item.category}</Typography>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => dispatch(addItem(item))}
                  sx={{ mt: 1 }}
                >
                  Add to Cart
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default GroceryList;
