
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  items: [],
  totalPrice: 0,
  filterCategory: 'all',
  sortBy: 'none',
  discount: 0,
  isHydrated: false,
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    hydrateCart: (state, action) => {
      return { ...state, ...action.payload, isHydrated: true };
    },
    addItem: (state, action) => {
      const existingItem = state.items.find(item => item.name === action.payload.name);
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        state.items.push({ ...action.payload, quantity: 1 });
      }
      state.totalPrice += action.payload.price;
      cartSlice.caseReducers.applyDiscount(state); 
      updateLocalStorage(state);
    },
    removeItem: (state, action) => {
      const index = state.items.findIndex(item => item.name === action.payload.name);
      if (index !== -1) {
        const item = state.items[index];
        if (item.quantity > 1) {
          item.quantity -= 1;
        } else {
          state.items.splice(index, 1);
        }
        state.totalPrice -= item.price;
      }
      cartSlice.caseReducers.applyDiscount(state); 
      updateLocalStorage(state);
    },
    setFilterCategory: (state, action) => {
      state.filterCategory = action.payload;
    },
    setSortBy: (state, action) => {
      state.sortBy = action.payload;
    },
    applyDiscount: (state) => {
      if (state.totalPrice > 500) {
        state.discount = 10; 
      } else {
        state.discount = 0;
      }
      state.totalPrice = state.totalPrice * (1 - state.discount / 100);
      updateLocalStorage(state);
    },
  },
});


export const loadCartFromStorage = () => (dispatch) => {
  if (typeof window !== 'undefined') {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      dispatch(cartSlice.actions.hydrateCart(JSON.parse(savedCart)));
    } else {
      dispatch(cartSlice.actions.hydrateCart(initialState));
    }
  }
};


const updateLocalStorage = (state) => {
  if (typeof window !== 'undefined') {
    localStorage.setItem(
      'cart',
      JSON.stringify({
        items: state.items,
        totalPrice: state.totalPrice,
        discount: state.discount,
      })
    );
  }
};

export const { hydrateCart, addItem, removeItem, setFilterCategory, setSortBy, applyDiscount } = cartSlice.actions;
export default cartSlice.reducer;
