import React from 'react';

import GroceryList from '../components/GroceryList';


export default function Home() {
  return (
   <>

      <div>
        <h1>Welcome to Grocery Store</h1>
        <GroceryList />
      
     
      </div>
   
   </>
  );
}


